# Create by AH, I use this from my virtual python setup
import setuptools
from setuptools import setup

setup(name='ccgfab',
    version='1.4',
    packages=setuptools.find_packages(),
)
