from setuptools import setup, find_packages
import sys, os

setup(name='ccg-django-backends',
      version='0.3',
      description="Custom backends written for the CCG.",
      long_description="""Provides custom backends written for the Centre for Comparative Genomics
at Murdoch University. Currently is provides ccg.django.auth.backends.LDAPBackend
and ccg.django.auth.backends.NoAuthModelBackend""",
      classifiers=[], # see http://pypi.python.org/pypi?:action=list_classifiers
      keywords='',
      author='Centre for Comparative Genomics',
      author_email='',
      url='http://code.google.com/p/ccg-django-extras/',
      license='GNU General Public License, version 2',
      namespace_packages=['ccg'],
      packages=find_packages(exclude=['examples', 'tests']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[],
      entry_points="",
      )
