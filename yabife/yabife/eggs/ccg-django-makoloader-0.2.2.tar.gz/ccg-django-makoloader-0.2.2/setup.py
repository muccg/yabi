from setuptools import setup, find_packages
import sys, os

setup(name='makoloader',
      version='0.2.2',
      description='Mako loader to use Mako templates within Django.',
      long_description='Mako loader to use Mako templates, used by the Centre for Comparative Genomics in our Django applications.',
      classifiers=[], # see http://pypi.python.org/pypi?:action=list_classifiers
      keywords='',
      author='Centre for Comparative Genomics',
      author_email='',
      url='http://code.google.com/p/makoloader/',
      license='GNU General Public License, version 2',
      namespace_packages=['ccg'],
      packages=find_packages(exclude=['examples', 'tests']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[],
      entry_points="",
      )


