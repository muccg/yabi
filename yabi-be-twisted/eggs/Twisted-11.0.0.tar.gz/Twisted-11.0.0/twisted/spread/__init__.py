
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Twisted Spread: Spreadable (Distributed) Computing.

Future Plans: PB, Jelly and Banana need to be optimized.

@author: Glyph Lefkowitz
"""
