import os
from setuptools import setup

setup(
    name = "TwistedWeb2",
    version = "10.2.0",
    description="An asynchronous networking framework written in "
                        "Python",
    author="Twisted Matrix Laboratories",
    author_email="twisted-python@twistedmatrix.com",
    maintainer="Glyph Lefkowitz",
    maintainer_email="glyph@twistedmatrix.com",
    url="http://twistedmatrix.com/",
    license="MIT",
    long_description="""\
An extensible framework for Python programming, with special focus
on event-based network programming and multiprotocol integration.
""",
    packages=['twistedweb2','twistedweb2/auth','twistedweb2/channel','twistedweb2/client','twistedweb2/filter'],
)
