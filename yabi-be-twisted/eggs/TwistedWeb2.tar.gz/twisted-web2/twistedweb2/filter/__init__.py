# -*- test-case-name: twistedweb2.test.test_cgi -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Output filters.
"""
