"""
Client and server implementations of http authentication
"""
