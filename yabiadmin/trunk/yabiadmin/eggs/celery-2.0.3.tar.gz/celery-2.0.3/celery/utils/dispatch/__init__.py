from celery.utils.dispatch.signal import Signal
