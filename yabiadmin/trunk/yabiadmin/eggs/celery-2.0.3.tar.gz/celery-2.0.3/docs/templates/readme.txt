=================================
 celery - Distributed Task Queue
=================================

.. image:: http://cloud.github.com/downloads/ask/celery/celery_favicon_128.png

.. include:: ../includes/introduction.txt

.. include:: ../includes/resources.txt
