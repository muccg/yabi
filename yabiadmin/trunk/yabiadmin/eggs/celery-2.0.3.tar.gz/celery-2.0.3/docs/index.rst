.. image:: http://cloud.github.com/downloads/ask/celery/celery_favicon_128.png
   :class: celerylogo

=================================
 Celery - Distributed Task Queue
=================================

Contents:

.. toctree::
    :maxdepth: 2

    getting-started/index
    userguide/index
    configuration
    cookbook/index
    tutorials/index
    faq
    reference/index
    internals/index
    changelog
    links


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

