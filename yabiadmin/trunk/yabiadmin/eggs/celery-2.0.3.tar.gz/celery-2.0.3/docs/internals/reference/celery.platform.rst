=====================================
 Platform Specific - celery.platform
=====================================

.. contents::
    :local:
.. currentmodule:: celery.platform

.. automodule:: celery.platform
    :members:
    :undoc-members:
