============================================
 Worker Scheduler - celery.worker.scheduler
============================================

.. contents::
    :local:
.. currentmodule:: celery.worker.scheduler

.. automodule:: celery.worker.scheduler
    :members:
    :undoc-members:
