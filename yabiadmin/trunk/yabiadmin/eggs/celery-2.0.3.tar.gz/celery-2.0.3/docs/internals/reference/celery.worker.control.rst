========================================
 Worker Control - celery.worker.control
========================================

.. contents::
    :local:
.. currentmodule:: celery.worker.control

.. automodule:: celery.worker.control
    :members:
    :undoc-members:
