===========
 Internals
===========

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    deprecation
    worker
    protocol
    events
    moduleindex
    reference/index
