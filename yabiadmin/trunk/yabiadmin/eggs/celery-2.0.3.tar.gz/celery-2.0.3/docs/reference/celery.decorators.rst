=====================================
 Task Decorators - celery.decorators
=====================================

.. contents::
    :local:
.. currentmodule:: celery.decorators

.. automodule:: celery.decorators
    :members:
    :undoc-members:
