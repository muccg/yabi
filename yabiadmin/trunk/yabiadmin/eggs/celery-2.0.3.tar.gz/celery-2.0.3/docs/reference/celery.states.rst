=============================
 Task States - celery.states
=============================

.. contents::
    :local:
.. currentmodule:: celery.states

.. automodule:: celery.states
    :members:
    :undoc-members:
