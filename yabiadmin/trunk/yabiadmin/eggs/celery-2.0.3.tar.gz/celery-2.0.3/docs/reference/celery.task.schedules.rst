==========================================================
 Periodic Task Schedule Behaviors - celery.task.schedules
==========================================================

.. contents::
    :local:
.. currentmodule:: celery.task.schedules

.. automodule:: celery.task.schedules
    :members:
    :undoc-members:
