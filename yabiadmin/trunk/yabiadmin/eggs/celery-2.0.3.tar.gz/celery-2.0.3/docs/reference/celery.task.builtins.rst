==============================================
 Built-in Task Classes - celery.task.builtins
==============================================

.. contents::
    :local:
.. currentmodule:: celery.task.builtins

.. automodule:: celery.task.builtins
    :members:
    :undoc-members:
