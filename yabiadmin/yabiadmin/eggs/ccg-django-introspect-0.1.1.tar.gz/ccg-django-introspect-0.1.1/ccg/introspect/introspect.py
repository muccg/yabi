from django.db import models
from django.forms.fields import *

field_type_map = {
    'IntegerField': int,
    'BooleanField': bool,
    'NullBooleanField': bool,
    'FloatField': float,
    'DecimalField': float
}                   

class Model(object):
    """
    Introspects a Django model or model instance to get information on the
    fields defined therein.
    
    Properties:
    fields      -- a dict of Field objects representing the model's fields and
                   foreign keys
    primary_key -- the Field object for the primary key

    Note that models with composite primary keys are not presently supported.
    """

    def __init__(self, model):
        """
        Constructs a Model object. The model parameter is expected to be either
        a Django model or model instance; a TypeError is raised if it's
        neither.
        """

        if isinstance(model, models.Model):
            self.model = model.__class__
        elif issubclass(model, models.Model):
            self.model = model
        else:
            raise TypeError("Expected a model class or instance; got neither")

        regular_fields = dict([(f.name, Field(f)) for f in self.model._meta.fields])
        many_to_many_fields = dict([(f.name, Field(f)) for f in self.model._meta.many_to_many])
        self.fields = dict(regular_fields, **many_to_many_fields)

        self.primary_key = self.fields[self.model._meta.pk.name]


class Field(object):
    """
    Introspects a Django field (whether a normal field, foreign key or many to
    many key) to extract information on the type of the field.

    Properties that are always present:
    foreign_key  -- boolean; true if the field is a foreign key (including
                    one-to-one keys)
    many_to_many -- boolean; true if the field is a many-to-many key
    name         -- the field's name
    primary_key  -- boolean; true if the field is a primary key
    type         -- the internal Django type of the field (example values
                    include "AutoField", "IntegerField" and "OneToOneField")

    Properties only present on foreign keys:
    one_to_one   -- boolean; true if the relationship is one-to-one

    Properties only present on foreign or many-to-many keys:
    to           -- the model class the key is related to

    Properties only present on many-to-many keys:
    via          -- the model class that represents the relationship, if
                    defined within the field definition
    """

    def __init__(self, field):
        self.field = field

        self.foreign_key = False
        self.many_to_many = False
        self.name = self.field.name
        self.primary_key = self.field.primary_key
        self.type = self.field.get_internal_type()
        if self.type in field_type_map:
            self.pythontype = field_type_map[self.type]
        else:
            self.pythontype = unicode

        if isinstance(field, models.fields.related.ManyToManyField):
            self.many_to_many = True
            self.to = self.field.rel.to
            self.via = self.field.rel.through
        elif hasattr(self.field, "related"):
            self.foreign_key = True
            self.one_to_one = (self.type == "OneToOneField")
            self.to = self.field.rel.to
