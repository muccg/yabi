# MySQL_old behaviour is identical to mysql base
from mysql import *