from django.contrib import admin
from django_evolution.models import Version, Evolution

admin.site.register(Version)
admin.site.register(Evolution)
