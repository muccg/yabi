from fabric.api import local, cd
from fabric.contrib.console import prompt
import os

def create_vc(env):
    if env.vc == 'svn':
        return SVN(env)
    elif env.vc == 'git':
        return GIT(env)
    elif env.vc == 'mercurial':
        return Mercurial(env)
    else:
       raise Exception("Invalid version control system: %s" % env.vc)

class VC(object):

    def checkout_tag(self):
        self.create_temp_dir()
        print self.list_tags()

        release = prompt('Please enter the release tag name: ')
        release = release.strip('/') # remove leading and trailing slashes so path is not mucked up
        
        self.get_tag(release)
    
        return release

    def checkout_trunk(self):
        self.create_temp_dir()
        print self.get_trunk()

        # we return the target name, which is snapshot for trunk (just to be inconsistent)
        return 'snapshot'

    def create_temp_dir(self):
        local('rm -rf fab-tmp')
        local('mkdir fab-tmp')

    # Methods to be implemented in VC specific subclasses below

    def list_tags(self):
        assert False, 'Method not implemented'
    
    def get_trunk(self):
        assert False, 'Method not implemented'

    def get_tag(self, tag_name):
        assert False, 'Method not implemented'


class SVN(VC):
    def __init__(self, env):
        VC.__init__(self)
        self.tags_url = env.svn_tags_url
        self.trunk_url = env.svn_trunk_url

    def list_tags(self):
        return local('svn list ' + self.tags_url)

    def get_trunk(self):
        local('svn checkout ' + self.trunk_url + ' ./fab-tmp/')

    def get_tag(self, tag_name):
        local('svn checkout ' + self.tags_url + '/' + tag_name + ' ./fab-tmp')

class GIT(VC):
    def __init__(self, env):
        VC.__init__(self)
        self.app_name = env.app_name
        self.git_url = os.path.join(env.git_trunk_url, self.app_name)
        self.app_dir = os.path.join('fab-tmp', self.app_name)

    def list_tags(self):
        return local('git tag -l')

    def get_trunk(self):
        self.clone()

    def get_tag(self, tag_name):
        self.clone()
        with cd(self.app_dir):
            local("git checkout " + tag_name)

    def clone(self):
        local("git clone %s %s" % (self.git_url, self.app_dir))

class Mercurial(VC):
    def __init__(self, env):
        VC.__init__(self)

    def list_tags(self):
        all_tags = local('hg tags -v', capture=True).split(os.linesep)
        public_tags = filter(lambda x: not x.endswith('local'), all_tags)
        release_tags = filter(lambda x: x.startswith('RELEASE'), public_tags)
        release_tag_names = map(lambda x: x.split()[0], release_tags)
        return os.linesep.join(reversed(release_tag_names))

    def get_trunk(self):
        self.get_tag('tip')

    def get_tag(self, tag_name):
        local("hg pull")
        local("hg archive -r %s %s" % (tag_name, 'fab-tmp'))

