from fabric.api import env, local, lcd
from fabric.contrib.console import confirm, prompt
import os
import vc

__all__ = [
    '_purge',
    '_virtual_python',
    '_chmod',
    '_apacheconfig',
    '_ccg_purge_user',
    '_ccg_purge_snapshot',
    '_ccg_deploy_user',
    '_ccg_deploy_snapshot',
    '_ccg_deploy_release',
    '_code_install',
    'restart',
    'ps']

env.repo_path = '' # supply path in repo if app_name not at top level
env.app_root = 'YOU NEED TO SET THIS'
env.app_name = 'YOU NEED TO SET THIS'
env.svn_trunk_url = 'YOU NEED TO SET THIS'
env.svn_tags_url = 'YOU NEED TO SET THIS'

env.writeable_dirs = ['scratch', 'logs']
env.alias_dirs = ['static']

env.auto_confirm_purge = False #purge without asking

env.content_excludes = ["fabfile.py", "ccgfab", ".git", ".gitignore","*.sql", "settings-*", "*.pyc", ".DS_Store", "*.conf", "*dblite", ".svn", ".hg", "eggs", "tmp", "scratch", "virtualpython"]
env.content_includes = ['*.py', '*.html', '*.mako', '*.txt', '*.png', '*.js', '*.css', '*.jpg', '*.gif', '*.pdf', '*.xml', '*.wsgi', '*.ttf', '*.swf', '*.flv', 'ext-?.?.?' ]

env.rsync_excludes = " ". join(['--exclude "%s"' % X for X in env.content_excludes])
env.rsync_includes = " ". join(['--include "%s"' % X for X in env.content_includes])

env.hosts = ['localhost']

env.ccg_python = '/usr/local/python/bin/python'
env.ccg_vpython = '/usr/local/etc/ccgbuild/virtual-python.py'
env.ccg_vpython_options = '--no-site-packages'
env.ccg_apacheconf = '/usr/local/python/conf/ccg-wsgi'


def _get_vc():
    """
    Load the appropriate version control functions
    """
    return vc.create_vc(env)

    
def _purge(target=''):
    """
    Purge a target
    """
    if env.auto_confirm_purge or confirm('Are you sure you want to purge ' + target + ' ?', default=False):
        print local('sudo rm -rf ' + target)


def _virtual_python(target=None, eggs_path=None):
    """
    Run the virutal python setup for a given target
    """
    vpython_target = target + '/virtualpython'

    if os.path.isfile(vpython_target + '/bin/python'):
        # already installed
        return

    print local(env.ccg_python + ' ' + env.ccg_vpython + ' ' + env.ccg_vpython_options + ' --prefix=' + vpython_target)
    print local(vpython_target + '/bin/python /usr/local/etc/ccgbuild/ez_setup.py')

    for filename in sorted(os.listdir(eggs_path)):
        filename_with_path = eggs_path + '/' + filename
        if os.path.isfile(filename_with_path):
            ext = os.path.splitext(filename_with_path)[-1]
            if (ext == '.gz') or (ext == '.egg') or (ext == '.tgz') or (ext == '.zip'):
                print local(vpython_target + '/bin/easy_install --allow-hosts=None ' + filename_with_path)


def _chmod(target):
    with lcd(target):
        for directory in env.writeable_dirs:
            print local("mkdir -p %s" % directory);
            print local('chmod 777 %s' % directory)


def _apacheconfig(target='', buildname='', install_name=''):
    print 'Doing Apacheconfig:'
    print 'target = ', target
    print 'buildname = ', buildname
    print 'install_name = ', install_name
    
    apacheconfig = env.ccg_apacheconf + '/' + install_name + '-' + buildname + '.conf'
    #Delete the old apache config
    print local('echo WSGIScriptAlias /' + install_name + '/' + buildname + ' ' + target + '/' + env.app_name + '.wsgi > ' + apacheconfig)
    for dir in env.alias_dirs:
        print local('echo Alias /' + install_name + '/' + buildname + '/' + dir + ' ' + target + '/' + dir + ' >> ' + apacheconfig)

def _purge_apacheconfig(buildname='', install_name=''):
    apacheconfig = env.ccg_apacheconf + '/' + install_name + '-' + buildname + '.conf'
    print local('sudo rm -f ' + apacheconfig)    


def _ccg_purge_user():
    """
    Purge a user deployment
    """
    for install_name in env.app_install_names:
        target = os.path.join(env.app_root, install_name, env.user)
        _purge(target)


def _ccg_purge_snapshot():
    """
    Purge a snapshot deployment
    """
    for install_name in env.app_install_names:
        target = os.path.join(env.app_root, install_name, 'snapshot')
        _purge(target)


def _ccg_deploy_user():
    """
    User deploy
    """

    src = './'
    _code_install(deploy_type=env.user, src=src, devrelease=True)

    return env.user


def _ccg_deploy_snapshot():
    """
    Snapshot deploy
    """
    _ccg_purge_snapshot()
    vc = _get_vc()
    release = vc.checkout_trunk()
    #purge the apache config
    for install_name in env.app_install_names:
        _purge_apacheconfig(release, install_name)
    src = os.path.join('fab-tmp/', env.repo_path, env.app_name) + '/'
    _code_install(deploy_type=release, src=src, devrelease=True)    
    print local('rm -rf fab-tmp')

    return 'snapshot'


def _ccg_deploy_release(devrelease=False):
    """
    Release deploy
    """
    vc = _get_vc()
    release = vc.checkout_tag()
    src = os.path.join('fab-tmp/', env.repo_path, env.app_name) + '/'
    _code_install(deploy_type=release, src=src, devrelease=devrelease)
    print local('rm -rf fab-tmp')
    return release

def _code_install(deploy_type=None, src=None, devrelease=False):
    """
    Code Install
    """
    for install_name in env.app_install_names:
        target = os.path.join(env.app_root, install_name, deploy_type, env.app_name)
        print local('mkdir -p ' + target)
        print local('rsync --delete %s %s -pthrvzC %s %s' % (env.rsync_excludes, env.rsync_includes, src, target))
        if devrelease:
            print local('cp %s %s' % (os.path.join(src, 'settings-dev.py'), os.path.join(target, 'settings.py')))
        else:
            print local('cp %s %s' % (os.path.join(src, 'settings-prod.py'), os.path.join(target, 'settings.py')))            

        _chmod(target)
        _virtual_python(target, os.path.join(src, 'eggs'))
        _apacheconfig(target, deploy_type, install_name)


def restart():
    """
    Restart Apache
    """
    print local("sudo /usr/local/python/bin/apachectl restart")


def ps():
    """
    List Apache processes
    """
    print local('ps -Af | grep apache')
