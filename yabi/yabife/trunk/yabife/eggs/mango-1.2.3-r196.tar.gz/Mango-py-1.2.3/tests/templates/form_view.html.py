from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1286793608.557704
_template_filename='templates/form_view.html'
_template_uri='form_view.html'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = []


def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'{% extends "base.html" %}\n{% block title %}Submit data{% endblock %}\n{% block content %}\n<h1>{{ message }}</h1>\n<form method=\'post\' action=\'.\'>\n{% if form.errors %}\n<p class=\'warning\'>Please correct the errors below:</p>\n{% endif %}\n<ul class=\'form\'>\n{{ form }}\n<li><input type=\'submit\' value=\'Submit\'></li>\n</ul>\n</form>\n\n{% endblock %}')
        return ''
    finally:
        context.caller_stack._pop_frame()


