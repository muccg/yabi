from django.contrib import admin
from django.contrib.webservices.ext import ExtJsonInterface
from models import *


class BasicAdmin(ExtJsonInterface, admin.ModelAdmin):
    pass


class ChildAdmin(ExtJsonInterface, admin.ModelAdmin):
    pass


class ManyBAdmin(ExtJsonInterface, admin.ModelAdmin):
    pass


admin.site.register(Basic, BasicAdmin)
admin.site.register(Child, ChildAdmin)
admin.site.register(ManyB, ManyBAdmin)
