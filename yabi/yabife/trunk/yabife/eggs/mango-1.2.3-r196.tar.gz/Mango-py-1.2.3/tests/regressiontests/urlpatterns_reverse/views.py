def empty_view(request, *args, **kwargs):
    pass

def kwargs_view(request, arg1=1, arg2=2):
    pass

def absolute_kwargs_view(request, arg1=1, arg2=2):
    pass
