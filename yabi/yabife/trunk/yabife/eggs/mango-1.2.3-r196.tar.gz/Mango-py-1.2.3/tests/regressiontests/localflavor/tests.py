import unittest
from django.test import TestCase

# just import your tests here
from us.tests import *
