"""cssutils unittests"""
__version__ = '$Id: __init__.py 1116 2008-03-05 13:52:23Z cthedot $'
