.. % $Id: ldap-schema.rst,v 1.1 2008/04/04 17:06:59 stroeder Exp $


:mod:`ldap.schema` Processing LDAPv3 sub schema sub entry
==============================================================

.. module:: ldap.schema
   :synopsis: Processing LDAPv3 sub schema sub entry
.. moduleauthor:: python-ldap project <python-ldap-dev@lists.sourceforge.net>


.. % Author of the module code;

.. _ldap.schema-example:

Examples for ldap.schema
^^^^^^^^^^^^^^^^^^^^^^^^

::

   import ldap.schema
