.. % $Id: ldap-dn.rst,v 1.1 2008/04/04 17:06:59 stroeder Exp $


:mod:`ldap.dn` LDAP Distinguished Name handling
====================================================

.. module:: ldap.dn
   :synopsis: LDAP Distinguished Name handling.
.. moduleauthor:: python-ldap project <python-ldap-dev@lists.sourceforge.net>


.. % Author of the module code;


.. seealso::

   For LDAPv3 DN syntax see:

   :rfc:`4514` - Lightweight Directory Access Protocol (LDAP): String Representation of Distinguished Names
   For LDAPv2 DN syntax (obsoleted by LDAPv3) see:

   :rfc:`1779` - A String Representation of Distinguished Names

The :mod:`ldap.dn` module defines the following functions:


.. function:: escape_dn_chars(s)

   This function escapes characters in string *s* which  are special in LDAP
   distinguished names. You should use  this function when building LDAP DN strings
   from arbitrary input.

   .. % -> string


.. function:: str2dn(s [, flags=:const:`0`])

   This function takes *s* and breaks it up into its component parts  down to AVA
   level. The optional parameter *flags* describes the DN format of s  (see
   :ref:`ldap-dn-flags`).

   .. % -> list


.. function:: dn2str(dn)

   This function takes a decomposed DN in *dn* and returns  a single string. It's
   the inverse to :func:`str2dn`.  Special characters are escaped with the help of
   function :func:`escape_dn_chars`.

   .. % -> string


.. function:: explode_dn(dn [, notypes=:const:`0` [, flags=:const:`0`]])

   This function takes *dn* and breaks it up into its component parts.   Each part
   is known as an RDN (Relative Distinguished Name). The optional  *notypes*
   parameter is used to specify that only the RDN values be   returned and not
   their types. The optional parameter *flags*  describes the DN format of s (see
   :ref:`ldap-dn-flags`).    This function is emulated by function
   :func:`str2dn`  since the function ldap_explode_dn() in the C library is
   deprecated.

   .. % -> list


.. function:: explode_rdn(rdn [, notypes=:const:`0` [, flags=:const:`0`]])

   This function takes a (multi-valued) *rdn* and breaks it up  into a list of
   characteristic attributes. The optional  *notypes* parameter is used to specify
   that only the RDN values be   returned and not their types. The optional *flags*
   parameter  describes the DN format of s (see :ref:`ldap-dn-flags`).    This
   function is emulated by function :func:`str2dn`  since the function
   ldap_explode_rdn() in the C library is deprecated.

   .. % -> list


.. _ldap-dn-example:

Examples
^^^^^^^^^

Splitting a LDAPv3 DN to AVA level:

>>> ldap.dn.str2dn('cn=Michael Str\xc3\xb6der,dc=stroeder,dc=com',flags=ldap.DN_FORMAT_LDAPV3)
[[('cn', 'Michael Str\xc3\xb6der', 4)], [('dc', 'stroeder', 1)], [('dc', 'com', 1)]]


Splitting a LDAPv2 DN into RDN parts:

>>> ldap.dn.explode_dn('cn=Michael Stroeder;dc=stroeder;dc=com',flags=ldap.DN_FORMAT_LDAPV2)
['cn=Michael Stroeder', 'dc=stroeder', 'dc=com']


Splitting a multi-valued RDN:

>>> ldap.dn.explode_rdn('cn=Michael Stroeder+mail=michael@stroeder.com',flags=ldap.DN_FORMAT_LDAPV2)
['cn=Michael Stroeder', 'mail=michael@stroeder.com']

Splitting a LDAPv3 DN with a multi-valued RDN into its AVA parts:


>>> ldap.dn.str2dn('cn=Michael Stroeder+mail=michael@stroeder.com,dc=stroeder,dc=com')
[[('cn', 'Michael Stroeder', 1), ('mail', 'michael@stroeder.com', 1)], [('dc', 'stroeder', 1)], [('dc', 'com', 1)]]

