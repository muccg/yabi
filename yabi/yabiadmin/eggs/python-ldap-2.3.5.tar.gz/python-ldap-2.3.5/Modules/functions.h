/* See http://python-ldap.sourceforge.net for details.
 * $Id: functions.h,v 1.3 2008/03/20 12:24:56 stroeder Exp $ */

#ifndef __h_functions_
#define __h_functions_

/* $Id: functions.h,v 1.3 2008/03/20 12:24:56 stroeder Exp $ */

#include "common.h"
extern void LDAPinit_functions( PyObject* );

#endif /* __h_functions_ */
