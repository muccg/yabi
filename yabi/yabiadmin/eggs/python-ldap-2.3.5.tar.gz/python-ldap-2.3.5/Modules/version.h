/* Set release version
 * See http://python-ldap.sourceforge.net for details.
 * $Id: version.h,v 1.3 2008/03/20 12:24:57 stroeder Exp $ */

#ifndef __h_version_
#define __h_version_


#include "common.h"
extern void LDAPinit_version( PyObject* d );

#endif /* __h_version_ */
