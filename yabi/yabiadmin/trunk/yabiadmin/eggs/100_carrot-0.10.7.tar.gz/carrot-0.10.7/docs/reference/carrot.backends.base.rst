=====================================
carrot.backends.base
=====================================

.. currentmodule:: carrot.backends.base

.. automodule:: carrot.backends.base
    :members:


