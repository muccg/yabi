=====================================
carrot.messaging
=====================================

The introduction to carrot that was here previously has been moved
to the `introduction`_ page.

.. _`introduction`: http://ask.github.com/carrot/introduction.html#examples

.. currentmodule:: carrot.messaging

.. automodule:: carrot.messaging
    :members:


