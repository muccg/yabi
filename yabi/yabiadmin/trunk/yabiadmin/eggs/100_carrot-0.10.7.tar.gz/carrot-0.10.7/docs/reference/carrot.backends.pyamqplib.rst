=====================================
carrot.backends.pyamqplib
=====================================

.. currentmodule:: carrot.backends.pyamqplib

.. automodule:: carrot.backends.pyamqplib
    :members:


