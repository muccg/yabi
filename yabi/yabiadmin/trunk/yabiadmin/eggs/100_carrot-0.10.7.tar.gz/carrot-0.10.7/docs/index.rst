.. Carrot documentation master file, created by sphinx-quickstart on Mon May 18 21:37:44 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Carrot Documentation
==================================

Contents:

.. toctree::
    :maxdepth: 3

    introduction
    faq
    reference/index
    changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

