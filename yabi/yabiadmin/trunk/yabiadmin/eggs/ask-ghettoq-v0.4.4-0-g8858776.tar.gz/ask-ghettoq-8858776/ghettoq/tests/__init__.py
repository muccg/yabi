from djangox.test.depth import alltests


def suite():
    return alltests(__file__, __name__)
