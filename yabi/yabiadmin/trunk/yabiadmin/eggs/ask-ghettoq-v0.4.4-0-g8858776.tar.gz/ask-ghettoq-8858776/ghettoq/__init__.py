"""Ghetto Queue using Redis or Django Models."""
VERSION = (0, 4, 4)
__version__ = ".".join(map(str, VERSION))
__author__ = "Ask Solem"
__contact__ = "askh@opera.com"
__homepage__ = "http://github.com/ask/ghettoq/"
__docformat__ = "restructuredtext"
__license__ = "BSD"
