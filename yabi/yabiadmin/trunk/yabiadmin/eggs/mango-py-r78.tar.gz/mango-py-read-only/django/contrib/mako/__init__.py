"""This brings in the django.contrib.mako.mako package into the root namespace. It adds the present directory to the python path, so we can dump the django.contrib.mako.mako source straight into the subdirectory and have it work correctly."""

import sys,os

# import it into the root space
sys.modules['mako']=__import__("mako",globals())
